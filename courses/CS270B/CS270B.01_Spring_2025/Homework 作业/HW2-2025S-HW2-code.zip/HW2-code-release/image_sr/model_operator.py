import torch
import torch.nn as nn
import torch.nn.functional as F


def Upsample(x, scale):
    out = TODO
    return out


def Downsample(x, scale):
    out = TODO
    return out
