# Super Resolution via Diffusion Models

## 部署

首先,下载一个在 `ImageNet-256` 数据集上预训练的 `diffusion model` ，地址为：[https://openaipublic.blob.core.windows.net/diffusion/jul-2021/256x256_diffusion_uncond.pt](https://openaipublic.blob.core.windows.net/diffusion/jul-2021/256x256_diffusion_uncond.pt)。并将其放在 `./checkpoint` 目录下。

## 环境

```bash
conda create -n cs270B python = 3.8
conda activate cs270B
pip install numpy torch blobfile tqdm pyYaml pillow torchmetrics torchvision
```

## 完成代码

你需要完成两个主要部分:

1. `solver_DC.py` 第 `124` 行的数据一致性校正操作。
2. `model_operator.py` 中的 `Upsample` 函数和 `Downsample` 函数。
   
## 运行

下面是一个例子，展示了如何运行代码, `--data_path` 是输入图像的路径，`--deg_scale` 是降采样的倍数，`--gpu` 是使用的GPU编号。

```bash
python main.py --data_path "./data/orig_3.png"  --deg_scale 4.0 --gpu 0
```
