import os
import random
import shutil
from pathlib import Path


def split_files(source_dir, test_ratio=0.1):
    """
    将指定目录下的文件随机分成两部分，按照指定比例

    参数:
        source_dir: 源文件目录
        test_ratio: 测试集比例 (默认为0.1，即1:9的分割)
    """
    # 创建目标目录
    source_path = Path(source_dir)
    if not source_path.exists():
        raise ValueError(f"源目录 {source_dir} 不存在!")

    # 获取所有文件列表（不包括子目录）
    all_files = [f for f in os.listdir(source_dir) if os.path.isfile(os.path.join(source_dir, f))]

    # 如果没有文件，退出
    if not all_files:
        print(f"目录 {source_dir} 中没有文件!")
        return

    # 随机打乱文件列表
    random.shuffle(all_files)

    # 计算分割点
    split_point = int(len(all_files) * test_ratio)

    # 分割文件列表
    test_files = all_files[:split_point]
    train_files = all_files[split_point:]

    # 创建结果目录
    base_dir = os.path.dirname(source_dir)
    train_dir = os.path.join(base_dir, "train")
    test_dir = os.path.join(base_dir, "test")

    os.makedirs(train_dir, exist_ok=True)
    os.makedirs(test_dir, exist_ok=True)

    # 拷贝文件到对应目录
    for file in train_files:
        src_path = os.path.join(source_dir, file)
        dst_path = os.path.join(train_dir, file)
        shutil.copy2(src_path, dst_path)

    for file in test_files:
        src_path = os.path.join(source_dir, file)
        dst_path = os.path.join(test_dir, file)
        shutil.copy2(src_path, dst_path)

    # 输出统计信息
    print(f"总文件数: {len(all_files)}")
    print(f"训练集文件数: {len(train_files)} ({len(train_files)/len(all_files):.1%})")
    print(f"测试集文件数: {len(test_files)} ({len(test_files)/len(all_files):.1%})")
    print(f"训练集文件保存在: {train_dir}")
    print(f"测试集文件保存在: {test_dir}")

    # 保存文件列表到文本文件
    with open(os.path.join(base_dir, "train_files.txt"), "w") as f:
        f.write("\n".join(train_files))

    with open(os.path.join(base_dir, "test_files.txt"), "w") as f:
        f.write("\n".join(test_files))

    print(
        f"文件列表已保存到: {os.path.join(base_dir, 'train_files.txt')} 和 {os.path.join(base_dir, 'test_files.txt')}"
    )


if __name__ == "__main__":
    source_directory = "data/sub_1K"
    split_files(source_directory, test_ratio=0.1)  # 1:9的比例分割
