import os
import json
import tqdm
import torch
import numpy as np

from diffusion_module.script_util import create_model
from torchmetrics.functional.image import (
    peak_signal_noise_ratio,
    structural_similarity_index_measure,
    learned_perceptual_image_patch_similarity,
)
from pathlib import Path
from utils import get_beta_schedule, data_transform, inverse_data_transform
import torchvision.utils as tvu
import PIL.Image as Image
import model_operator


class Diffusion:
    def __init__(self, args, config, device=None):
        self.args = args
        self.args.save_path = Path(self.args.save_path)
        (self.args.save_path / "progress").mkdir(parents=True, exist_ok=True)
        self.config = config
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.model_var_type = config.model.var_type
        betas = get_beta_schedule(
            beta_schedule=config.diffusion.beta_schedule,
            beta_start=config.diffusion.beta_start,
            beta_end=config.diffusion.beta_end,
            num_diffusion_timesteps=config.diffusion.num_diffusion_timesteps,
        )
        self.betas = torch.from_numpy(betas).float().to(self.device)
        self.num_timesteps = self.betas.shape[0]

        alphas = 1.0 - self.betas
        alphas_cumprod = alphas.cumprod(dim=0)
        alphas_cumprod_prev = torch.cat([torch.ones(1, device=self.device), alphas_cumprod[:-1]], dim=0)
        self.alphas_cumprod_prev = alphas_cumprod_prev
        posterior_variance = self.betas * (1.0 - alphas_cumprod_prev) / (1.0 - alphas_cumprod)
        if self.model_var_type == "fixedlarge":
            self.logvar = self.betas.log()
        elif self.model_var_type == "fixedsmall":
            self.logvar = posterior_variance.clamp(min=1e-20).log()

    def sample(self):
        config_dict = vars(self.config.model)
        model = create_model(**config_dict)
        if self.config.model.use_fp16:
            model.convert_to_fp16()

        ckpt = os.path.join(self.args.exp, "./checkpoint/256x256_diffusion_uncond.pt")
        model.load_state_dict(torch.load(ckpt, map_location=self.device))
        print(f"Model ckpt loaded from {ckpt}")
        model.to(self.device)
        model.eval()

        print(
            f"Run Sampling with Data Consistency.\n"
            f"== {self.args.T_sampling} sampling steps.\n"
            f"== Task: {self.args.deg}.\n"
            f"== Degradation scale: {self.args.deg_scale}.\n"
            f"== Data path: {self.args.data_path}.\n"
            f"== Save path: {self.args.save_path}."
        )
        self.Sampler_with_DC(model)

    def Sampler_with_DC(self, model):
        """使用数据一致性的采样器进行反向扩散采样"""
        scale = round(self.args.deg_scale)
        # TODO: 请自行实现正向算子 A 和 伴随算子 AT
        A = lambda z: model_operator.Downsample(z, scale)
        AT = lambda z: model_operator.Upsample(z, scale)

        # 加载原始图像并预处理
        x_gt = Image.open(self.args.data_path).convert("RGB")
        x_gt = np.array(x_gt).astype(np.float32) / 255.0
        x_gt = torch.from_numpy(x_gt.transpose(2, 0, 1)).unsqueeze(0).to(self.device)
        x_gt = data_transform(self.config, x_gt)

        y = A(x_gt)
        ATy = AT(y)

        tvu.save_image(inverse_data_transform(self.config, y), str(self.args.save_path / "measurement.png"))
        tvu.save_image(inverse_data_transform(self.config, ATy), str(self.args.save_path / "ATy.png"))
        tvu.save_image(inverse_data_transform(self.config, x_gt), str(self.args.save_path / "GT.png"))

        # 初始化噪声图像
        x = torch.randn(
            1,
            self.config.data.channels,
            self.config.data.image_size,
            self.config.data.image_size,
            device=self.device,
        )

        with torch.no_grad():
            skip = self.config.diffusion.num_diffusion_timesteps // self.args.T_sampling
            xs = [x]
            times = list(range(0, 1000, skip))
            times_next = [-1] + times[:-1]
            times_pair = zip(reversed(times), reversed(times_next))

            for i, j in tqdm.tqdm(times_pair, total=len(times)):
                t = torch.full((x.size(0),), i, device=self.device, dtype=torch.long)
                next_t = torch.full((x.size(0),), j, device=self.device, dtype=torch.long)

                at = compute_alpha(self.betas, t)
                at_next = compute_alpha(self.betas, next_t)

                xt = xs[-1]
                et = model(xt, t)
                et = et[:, :3] if et.size(1) == 6 else et

                # Tweedie Denoising 得到 x0_t
                x0_t = (xt - et * torch.sqrt(1 - at)) / torch.sqrt(at)
                tvu.save_image(
                    inverse_data_transform(self.config, x0_t),
                    str(self.args.save_path / "progress" / f"reco_{str(j).zfill(3)}.png"),
                )

                # TODO: 数据一致性校正
                # 请自行实现数据一致性操作,可以使用任何方法,例如 DDNM 或 DPS.
                x0_t_hat = TODO
                # =================================================
                
                eta = self.args.eta
                c1 = torch.sqrt(1 - at_next) * eta
                c2 = torch.sqrt(1 - at_next) * ((1 - eta**2) ** 0.5)

                # DDIM 采样
                xt_next = (
                    (torch.sqrt(at_next) * x0_t_hat + c1 * torch.randn_like(x0_t_hat) + c2 * et)
                    if j != 0
                    else x0_t_hat
                )

                xs.append(xt_next)
            x = xs[-1]

        tvu.save_image(inverse_data_transform(self.config, x), str(self.args.save_path / "recon_final.png"))

        # 计算指标
        x_gt_img = inverse_data_transform(self.config, x_gt)
        x_img = inverse_data_transform(self.config, x)
        psnr = peak_signal_noise_ratio(x_gt_img, x_img).item()
        ssim = structural_similarity_index_measure(x_gt_img, x_img).item()
        lpips = learned_perceptual_image_patch_similarity(x_gt_img, x_img).item()
        print(f"PSNR: {psnr:.4f}, SSIM: {ssim:.4f}, LPIPS: {lpips:.4f}")
        summary = {"results": {"PSNR": psnr, "SSIM": ssim, "LPIPS": lpips}}
        with open(str(self.args.save_path / "summary.json"), "w") as f:
            json.dump(summary, f)


def compute_alpha(beta, t):
    beta = torch.cat([torch.zeros(1, device=beta.device), beta], dim=0)
    a = (1 - beta).cumprod(dim=0)
    return a.index_select(0, t + 1).view(-1, 1, 1, 1)
