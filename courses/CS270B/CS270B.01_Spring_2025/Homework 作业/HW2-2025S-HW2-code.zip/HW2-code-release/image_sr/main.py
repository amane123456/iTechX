import argparse
import logging
import traceback
import sys
import os
import yaml
import torch
import numpy as np
from solver_DC import Diffusion

torch.set_printoptions(sci_mode=False)


def parse_args_and_config():
    parser = argparse.ArgumentParser(description="Diffusion Sampling Application")
    parser.add_argument("--config", type=str, default="imagenet_256.yml", help="Path to the config file")
    parser.add_argument("--seed", type=int, default=1234, help="Random seed")
    parser.add_argument("--exp", type=str, default="exp", help="Save path for experiment data")
    parser.add_argument("--deg", type=str, default="SR", help="Degradation type")
    parser.add_argument("--eta", type=float, default=0.85, help="Eta value")
    parser.add_argument("--deg_scale", type=float, default=0.0, help="Degradation scale")
    parser.add_argument("--T_sampling", type=int, default=1000, help="Number of sampling steps")
    parser.add_argument("--gpu", type=int, default=0, help="GPU ID")
    parser.add_argument("--save_path", type=str, default="results", help="Folder to save results")
    parser.add_argument("--data_path", type=str, default="data/orig_1.png", help="Test dataset path")
    parser.add_argument(
        "--verbose", type=str, default="info", help="Logging level: info | debug | warning | critical"
    )
    args = parser.parse_args()

    # 设置日志配置
    numeric_level = getattr(logging, args.verbose.upper(), None)
    if not isinstance(numeric_level, int):
        raise ValueError(f"Unsupported logging level: {args.verbose}")
    logging.basicConfig(
        level=numeric_level,
        format="%(levelname)s - %(filename)s - %(asctime)s - %(message)s",
        stream=sys.stdout,
    )

    # 解析配置文件
    with open(os.path.join("configs", args.config), "r") as f:
        config_dict = yaml.safe_load(f)
    config = dict2namespace(config_dict)

    # 处理保存路径
    problem_name = f"{args.deg}_{args.deg_scale}_{os.path.splitext(os.path.basename(args.data_path))[0]}"
    logging.info(f"Problem name: {problem_name}")
    args.save_path = os.path.join(args.save_path, problem_name)
    os.makedirs(args.save_path, exist_ok=True)

    # 设置设备
    device = torch.device(f"cuda:{args.gpu}" if torch.cuda.is_available() else "cpu")
    logging.info(f"Using device: {device}")
    config.device = device

    # 设置随机种子
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.benchmark = True

    return args, config


def dict2namespace(config):
    ns = argparse.Namespace()
    for k, v in config.items():
        setattr(ns, k, dict2namespace(v) if isinstance(v, dict) else v)
    return ns


def main():
    args, config = parse_args_and_config()
    try:
        runner = Diffusion(args, config)
        runner.sample()
    except Exception:
        logging.error(traceback.format_exc())
    return 0


if __name__ == "__main__":
    sys.exit(main())
