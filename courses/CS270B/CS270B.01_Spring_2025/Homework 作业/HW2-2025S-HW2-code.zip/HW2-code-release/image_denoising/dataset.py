import numpy as np
import utils
from torch.utils import data


class TrainData(data.Dataset):
    def __init__(self, clean_img, noise_level, noise_type):
        self.clean = clean_img
        self.noise_level = noise_level
        self.noise_type = noise_type

    def __getitem__(self, item):
        clean = self.clean[item]

        if self.noise_type == 'Gaussian':
            noisy_1 = utils.Gaussian_noise(clean, self.noise_level) / 255.
            noisy_2 = utils.Gaussian_noise(clean, self.noise_level) / 255.
        elif self.noise_type == 'Poisson':
            noisy_1 = utils.Poisson_noise(clean, self.noise_level) / 255.
            noisy_2 = utils.Poisson_noise(clean, self.noise_level) / 255.
        else:
            raise ValueError(f"Unknown noise type: {self.noise_type}")

        return noisy_1.astype(np.float32), noisy_2.astype(np.float32)

    def __len__(self):
        return len(self.clean)


class ValidData(data.Dataset):
    def __init__(self, noisy_data):
        self.noisy = noisy_data

    def __getitem__(self, item):
        return self.noisy[item]

    def __len__(self):
        return len(self.noisy)
