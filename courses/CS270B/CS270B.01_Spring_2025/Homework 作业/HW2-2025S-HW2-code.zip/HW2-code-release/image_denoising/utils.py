import os

import numpy as np
from skimage import io as skio
from skimage.metrics import structural_similarity


def Gaussian_noise(img, noise_level, isClip=True):
    #################################################
    # TODO: 1. implement Gaussian noise here        #
    #################################################

    noisy_img = "TODO: implement Gaussian noise here"
    if isClip == True:
        noisy_img = np.clip(noisy_img, 0, 255)
    return noisy_img


def Poisson_noise(img, noise_level, isClip=True):
    #################################################
    # TODO: 2. implement Poisson noise here         #
    #################################################

    noisy_img = "TODO: implement Poisson noise here"
    if isClip == True:
        noisy_img = np.clip(noisy_img, 0, 255)
    return noisy_img


def mask_pixel(img, i):
    ###############################################################
    # TODO: 3. implement mask image function                      #
    # you can get hints at https://github.com/czbiohub/noise2self #
    ###############################################################
    pass


def ssim(img, ground_truth):
    N = img.shape[0]
    res = []
    for k in range(N):
        data_range = np.max(ground_truth[k]) - np.min(ground_truth[k])
        res.append(structural_similarity(img[k], ground_truth[k], data_range=data_range))
    res = np.array(res)
    return res


def psnr(img, ground_truth):
    N = img.shape[0]
    res = []
    for k in range(N):
        mse = np.mean((img[k] - ground_truth[k]) ** 2)
        if mse == 0.:
            return float('inf')
        data_range = np.max(ground_truth[k]) - np.min(ground_truth[k])
        res.append(20 * np.log10(data_range) - 10 * np.log10(mse))
    return np.array(res)


def load_data(data_path):
    img_lst = []
    for filename in os.listdir(data_path):
        img = skio.imread(os.path.join(data_path, filename))
        img_lst.append(img)
    img_lst = np.array(img_lst)
    return img_lst


def save_img(img, save_path):
    os.makedirs(save_path, exist_ok=True)
    img = img.astype(np.uint8)
    for i in range(len(img)):
        s = str(i).zfill(2)
        skio.imsave(os.path.join(save_path, f"{s}.png"), img[i])
