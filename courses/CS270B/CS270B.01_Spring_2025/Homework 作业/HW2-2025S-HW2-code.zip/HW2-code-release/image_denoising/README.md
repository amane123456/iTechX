# CS270B-Spring-2024-HW2-Image-Denoising

This is a section of CS270B Spring 2024 homework 2. The objective of this assignment is to comprehend image noise types
and acquire knowledge of self-supervised learning techniques for image denoising.

## What you need to do?

- Implement the **Gaussian** noise generator and the **Poisson** noise generator.
- Implement the training part of the `Noise2Noise` method.
- Implement the `mask_pixel` function of the `Noise2Self` method.

