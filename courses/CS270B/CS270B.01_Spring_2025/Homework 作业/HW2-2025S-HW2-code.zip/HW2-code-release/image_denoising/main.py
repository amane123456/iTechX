import os

import commentjson as json
import numpy as np
import torch
from torch.utils import data
from tqdm import tqdm

import dataset
import model
import utils


def validate_config(config):
    # Example validation - expand based on actual requirements
    assert os.path.exists(config["file"]["file_path"]), "Data file path does not exist."
    assert config["train"]["epoch"] > 0, "Epoch count must be positive."


def prepare_data(config, noise_type=None, noise_level=None):
    data_path = config["file"]["file_path"]
    clean_img = utils.load_data(data_path).astype(np.float32)

    if noise_type == 'Gaussian':
        noisy_img = utils.Gaussian_noise(clean_img, noise_level=noise_level) / 255.
    elif noise_type == 'Poisson':
        noisy_img = utils.Poisson_noise(clean_img, noise_level=noise_level) / 255.
    else:
        raise ValueError(f"Unknown noise type: {noise_type}")

    utils.save_img(noisy_img * 255, config["file"]["valid_path"])

    return clean_img, noisy_img.astype(np.float32)


def get_data_loaders(clean_img, noisy_img, batch_size, noise_type='Gaussian', noise_level=25):
    train_loader = data.DataLoader(
        dataset=dataset.TrainData(clean_img, noise_level, noise_type=noise_type),
        batch_size=batch_size,
        shuffle=True
    )

    valid_loader = data.DataLoader(
        dataset=dataset.ValidData(noisy_img),
        batch_size=batch_size,
        shuffle=False
    )

    return train_loader, valid_loader


def train(method, model, train_loader, valid_loader, device, epoch, save_epoch, save_path, clean_img):
    loss_fun = torch.nn.MSELoss().to(device)
    optimizer = torch.optim.Adam(params=model.parameters())
    loop_tqdm = tqdm(range(epoch), leave=False)

    for e in loop_tqdm:
        model.train()
        loss_log = 0
        for i, batch in enumerate(train_loader):
            if method == "Noise2Noise":
                noisy_1, noisy_2 = batch
                noisy_1 = noisy_1.to(device).unsqueeze(1)
                noisy_2 = noisy_2.to(device).unsqueeze(1)

                ############################################################
                # TODO: 1. Implement Noise2Noise                           #
                # * hint: consider the N2N loss and the input and target   #
                ############################################################
                pass

            elif method == "Noise2Self":
                noisy, _ = batch

                ############################################################
                # TODO: 2. Implement utils.mask_pixel function             #
                ############################################################

                masked_noisy, mask = utils.mask_pixel(noisy, i)
                noisy = noisy.to(device).unsqueeze(1)
                masked_noisy = masked_noisy.to(device).unsqueeze(1)
                mask = mask.to(device).unsqueeze(1)

                output = model(masked_noisy)
                loss = loss_fun(output * mask, noisy * mask)
            else:
                raise ValueError(f"Unknown method: {method}")

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            loss_log = loss_log + loss.item()

        loop_tqdm.set_postfix(loss=loss_log / len(train_loader))

        if (e + 1) % save_epoch == 0:
            with torch.no_grad():
                output = None
                for i, noisy in enumerate(valid_loader):
                    noisy = noisy.unsqueeze(1).to(device)
                    output = model(noisy).squeeze(1).cpu().numpy()

                denoised_img = output.clip(0, 1)
                psnr_index = np.mean(utils.psnr(denoised_img, clean_img / 255.))
                ssim_index = np.mean(utils.ssim(denoised_img, clean_img / 255.))

                print('PSNR:{:.4f}'.format(psnr_index), 'SSIM:{:.4f}'.format(ssim_index))
                utils.save_img(denoised_img * 255, save_path)


def general_train(config_path, method="Noise2Noise"):
    with open(config_path) as config_file:
        config = json.load(config_file)
    validate_config(config)

    device = torch.device(f"cuda:{config['train']['gpu']}" if torch.cuda.is_available() else "cpu")
    network = model.Unet().to(device)

    clean_img, noisy_img_valid = prepare_data(
        config,
        noise_type=config["noise"]["type"],
        noise_level=config["noise"]["noise_level"]
    )

    train_loader, valid_loader = get_data_loaders(
        clean_img,
        noisy_img_valid,
        batch_size=config["train"]["batch_size"],
        noise_type=config["noise"]["type"],
        noise_level=config["noise"]["noise_level"]
    )

    train(
        method,
        network,
        train_loader,
        valid_loader,
        device,
        epoch=config["train"]["epoch"],
        save_epoch=config["train"]["save_epoch"],
        save_path=config["file"]["save_path"],
        clean_img=clean_img
    )


if __name__ == '__main__':
    config_path = 'config-gaussian.json'
    # config_path = 'config-poisson.json'
    method_name = "Noise2Noise"
    # method_name = "Noise2Self"
    general_train(config_path, method_name)
