import utils
from torch.utils import data
from skimage import io as skio


class TrainData(data.Dataset):
    def __init__(self, file_path):
        self.img = skio.imread(file_path) / 255.0
        self.h, self.w = self.img.shape
        self.xy = utils.grid_coordinate(h=self.h, w=self.w).reshape(-1, 2)
        self.img = self.img.reshape(-1, 1)

    def __getitem__(self, item):
        return self.xy[item], self.img[item]

    def __len__(self):
        return self.xy.shape[0]


class TestData(data.Dataset):
    def __init__(self, h, w):
        self.h, self.w = h, w
        self.xy = utils.grid_coordinate(h=self.h, w=self.w).reshape(1, int(h * w), 2)

    def __getitem__(self, item):
        return self.xy[item]  # (h*w, 2)

    def __len__(self):
        return 1
