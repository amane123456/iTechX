import numpy as np
import torch
import math


def fourier_feature_mapping(xyz, B):
    """
    Fourier Feature Mapping Function
    """
    xyz_embedding_cos = torch.cos(xyz.float() @ B.float() * 2 * math.pi)
    xyz_embedding_sin = torch.sin(xyz.float() @ B.float() * 2 * math.pi)
    xyz_embedding = torch.cat([xyz_embedding_cos, xyz_embedding_sin], dim=1)

    return xyz_embedding


def psnr(image, ground_truth):
    # TODO: implement PSNR
    pass


def ssim(image, ground_truth):
    # TODO: implement SSIM
    pass


def grid_coordinate(h, w):
    x = np.linspace(0, 1, h)
    y = np.linspace(0, 1, w)
    x, y = np.meshgrid(x, y, indexing="ij")  # (h, w), (h, w)
    xy = np.stack([x, y], -1).reshape(-1, 2)  # (h*w, 2)

    return xy
