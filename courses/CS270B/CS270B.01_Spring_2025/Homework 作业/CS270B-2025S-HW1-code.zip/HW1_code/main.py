import torch
import dataset
from tqdm import tqdm
import model
import utils
from skimage import io as skio
import commentjson as json
from torch.utils import data
from skimage import img_as_ubyte
import numpy as np
import os


def train(config_path):
    with open(config_path) as config_file:
        config = json.load(config_file)

    # File Parameters
    file_path = config["file"]["file_path"]
    out_path = config["file"]["out_path"]
    os.makedirs(out_path, exist_ok=True)

    h, w = config["file"]["h"], config["file"]["w"]

    # Training Parameters
    lr = config["train"]["lr"]
    gpu = config["train"]["gpu"]
    epoch = config["train"]["epoch"]
    save_epoch = config["train"]["save_epoch"]
    batch_size = config["train"]["batch_size"]
    device = torch.device(f"cuda:{gpu}" if torch.cuda.is_available() else "cpu")

    # Fourier Feature Mapping Parameters
    fourier_dim = config["network"]["fourier_dim"]
    b_matrix = np.random.randn(int(fourier_dim / 2), 2) * 5
    B_tensor = torch.tensor(b_matrix.T).to(device)

    # Data Loader
    train_loader = data.DataLoader(
        dataset=dataset.TrainData(file_path=file_path), batch_size=batch_size, shuffle=True
    )
    test_loader = data.DataLoader(dataset=dataset.TestData(h=h, w=w), batch_size=1, shuffle=False)

    # Model Training
    loss_fn = torch.nn.MSELoss().to(device)
    network = model.mlp(in_dim=fourier_dim).to(device)
    optimizer = torch.optim.Adam(params=network.parameters(), lr=lr)

    # Training
    for e in tqdm(range(epoch), desc="Epoch", leave=False):
        network.train()
        total_loss = 0
        for xy, img in train_loader:
            xy, img = xy.to(device).float().view(-1, 2), img.to(device).float().view(-1, 1)
            xy = utils.fourier_feature_mapping(xyz=xy, B=B_tensor)
            img_pre = network(xy)
            loss = loss_fn(img_pre, img.to(img_pre.dtype))
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        print(f"Epoch {e + 1} Loss: {total_loss / len(train_loader)}")
        # Save Image
        if (e + 1) % save_epoch == 0:
            network.eval()
            with torch.no_grad():
                for xy in test_loader:
                    xy = xy.to(device).float().view(-1, 2)
                    xy = utils.fourier_feature_mapping(xyz=xy, B=B_tensor)
                    img_pre = network(xy).view(h, w).cpu().numpy()
                    skio.imsave(f"{out_path}/ship_{e + 1}.tif", img_as_ubyte(img_pre))


if __name__ == "__main__":
    train("config.json")
